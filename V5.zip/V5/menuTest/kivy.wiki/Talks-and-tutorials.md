## Kivy Video Tutorials

* [kivy interactive sandbox](http://www.youtube.com/watch?v=S2sFqFGDu1k) by tshirtman
* [tutorial by](http://www.youtube.com/watch?v=fc1GZXRWy_A) by Zogg
* [tutorial(link missing)] by Ernesto Rico
* [tutorial](http://urtalk.kpoint.com/kapsule/gcc-5ad9712e-5337-405c-9fb3-e5ff63a3ccd4) by Jorge
* [talks given](http://kivy.org/#aboutus) by the Kivy Team
* [tutorial](Http://pyvideo.org/video/2259/kivy-creating-desktop-and-mobile-apps-with-pyth) by brousch at PyOhio 2013
* [Kivy crash course](https://www.youtube.com/watch?v=F7UKmK9eQLY) by Alexander Taylor (inclement), a series of youtube video tutorials.

## More Kivy Talks

* [Engaging call for help about Kivy in Guido's Keynote](https://www.youtube.com/watch?v=0Ef9GudbxXY&feature=youtu.be&t=11m20s) by Guido Van Rossum for PyCon US 2014
* [An Introduction to Kivy: The KV Language and Common Mistakes](http://www.youtube.com/watch?v=3gzZbsKlFMs) by Jacob Kovac for Utah Python August 2013 Meeting. ([github of presentation code](https://github.com/Kovak/KivyExamples))
* [Developing with Kivy and Python](http://www.youtube.com/watch?v=tyuBeNmnKcc) by Andreas Schreiber at DroidCon 2013
* [Programming Mobile Apps with Python](https://ep2013.europython.eu/conference/talks/programming-mobile-apps-with-python) by Andreas Schreiber for EuroPython 2012
Don't hesitate to add to the list by clicking the edit button at the bottom

##
##Comments
Add your comments here 