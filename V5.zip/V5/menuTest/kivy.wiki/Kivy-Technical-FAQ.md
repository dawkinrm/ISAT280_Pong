# Kivy Technical FAQ
A place to document miscellaneous Kivy programming tips, tricks, hacks, etc.

## KVLANG FAQ

## Kivy Python FAQ

## Miscellany
* When do I make a property a Kivy class-level property, and when should I not?

Recall from the [Kivy Properties documentation](http://kivy.org/docs/api-kivy.properties.html?highlight=properties#kivy.properties) that the services provided by making something a Kivy Property are:
>
* Value Checking / Validation:
    When you assign a new value to a property, the value is checked against validation constraints. For example, validation for an OptionProperty will make sure that the value is in a predefined list of possibilities. Validation for a NumericProperty will check that your value is a numeric type. This prevents many errors early on.
* Observer Pattern:
    You can specify what should happen when a property’s value changes. You can bind your own function as a callback to changes of a Property. If, for example, you want a piece of code to be called when a widget’s pos property changes, you can bind a function to it.
* Better Memory Management:
    The same instance of a property is shared across multiple widget instances.

Thus, if you think you will want to use any of those services in conjunction with an attribute, you should probably default to making that attribute a Kivy property.  (Occasionally there may be a performance penalty in doing so, but generally speaking, it is advisable to err on the side of using what the Kivy devs have provided, and then later re-factor if such a performance hit becomes noticeable and detrimental.  Just remember to avoid using Kivy "keywords," which vary somewhat from class to class, when re-factoring, lest you over-ride something unintentionally.)  