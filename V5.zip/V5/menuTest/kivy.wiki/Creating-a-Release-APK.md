**Instructions for creating a signed, release APK, suitable for the Google Play Store**

### Fields

* **my-project** - The directory for your project
* **my-new-key** - The name of the key you generate
* **my-alias** - A short alias name for the key
* **MyProject** - The name of your project, and APK
* **version** - The version of this APK (not Kivy version)

### Commands

```
$ cd ~
$ keytool -genkey -v -keystore ./keystores/<my-new-key>.keystore -alias <my-alias> -keyalg RSA -keysize 2048 -validity 10000
$ cd ~/<my-project>
$ source venv/bin/activate
$ buildozer android release
$ cd ~
$ jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore ./keystores/<my-new-key>.keystore ./<my-project>/bin/<MyProject>-<version>-release-unsigned.apk <my-alias>
$ <key-password>
$ .buildozer/android/platform/android-sdk-21/tools/zipalign -v 4 ./<my-project>/bin/<MyProject>-<version>-release-unsigned.apk ./<my-project>/bin/<MyProject>.apk
```