## Summary

* *author: Alexander Taylor*
* *kivy: >= 1.7.2 (and probably earlier, not tested)*

A simple example of how to create a Label-like widget that automatically wraps its text and becomes user-scrollable if the text exceeds the widget's height.

## Usage

The implementation is very simple, and only lets the user set the text of the ScrollableLabel. You would simply create the widget normally as follows (or the equivalent in kv).

```
some_label = ScrollableLabel(text='some long .... ... ... ... long .... . .. .... .. . text!')
```
Since the ScrollableLabel is really a ScrollView, you can set all the normal ScrollView properties if you like. You could also make simple modifications to the example to let you set the label's font_size, color etc easily by just copying what I did to pass its text through.

The code file below defines a full example App as well as just the ScrollableLabel widget, so you can run it to try it out.

## Files

#### file.py
```python
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.properties import StringProperty
from kivy.lang import Builder

long_text = 'yay moo cow foo bar moo baa ' * 100

Builder.load_string('''
<ScrollableLabel>:
    Label:
        size_hint_y: None
        height: self.texture_size[1]
        text_size: self.width, None
        text: root.text
''')

class ScrollableLabel(ScrollView):
    text = StringProperty('')

class ScrollApp(App):
    def build(self):
        return ScrollableLabel(text=long_text)

if __name__ == "__main__":
    ScrollApp().run()
```

##Comments
# Section for user comments



