## From Kivy's Application Gallery

**[[The Gallery|http://kivy.org/#gallery]]**

* [[Particle Panda|http://www.particlepanda.com/]] by [[Chaos Buffalo Labs|http://www.chaosbuffalolabs.com/]] (broken link)
* [[Yeco|http://www.multitouchmusic.com/software-2/yeco/]] by Graham Comerford (broken link)
* [[Processcraft|http://showgen.com/]] by [[Showgen Ltd|http://showgen.com/]] (broken link)
* TicTacTouch by Dominique Burnand and Livio Conzett
* [[Bargenius|http://fresklabs.com/projects/bargenius]] by [[Fresk interactive|http://fresk.co/]]
* [[Kaleidoscope|http://github.com/tito/kaleidoscope/]] by [[Erasme|http://erasme.org/]]
* [[Touch Live|http://github.com/grmcom/touchlive/]] by Graham Comerford
* [[Icarus Touch|https://github.com/stocyr/icarustouch]] by Cyril Stoller from [[Liquid Rain|http://www.liquidrain.net/]]
* [[The noBOOTH|http://thenobooth.com/]] by [[Fresk interactive|http://fresk.co/]]
* [[Plane White|https://github.com/theoo/planewhite]] by [[Complex IT|http://www.complex.ch/]] and [[Carina Ow|http://carinaow.com/]] 


## **[[Kivy's Programming Contest|http://kivy.org/#contest]]**

### From Kivy's First Programming Contest

* 1st Place: [[Deflectouch|http://github.com/stocyr/deflectouch/]] by Cyril Stoller
* 2nd Place: [[Fishlife|http://github.com/zogg/fishlife]] by Zogg
* 3rd Place: [[Memorykivy|http://github.com/niavlys/memorykivy/]] by Niavlys

### From Kivy's Second Programming Contest

* 1st place: [Opolo](https://github.com/valentin12/kivy_frogs), by Valentin Pratz
* 2nd place: [Grashof's condition (fourbar)](https://github.com/tygart/fourbar), by Ken Geronilla
* 3rd place: [ArithmeBricks](https://github.com/zuo/ArithmeBricks), by Jan Kaliszewski (zuo)

### Kivy app of the month 2015

* Kivy App of the Month, January 2015: [Best Vibrator (Material)](https://plus.google.com/102482050431251779760/posts/KrL4EGFQajj)
* Kivy App of the Month, February 2015: [Pithon](https://plus.google.com/102482050431251779760/posts/WKzuMWWx7xU)

## Kivy Apps on Google Play

* [[2048|http://play.google.com/store/apps/details?id=com.meltingrocks.kivy2048]]
* [[SpaceSheep Enterprises LLC: Number Lane|https://play.google.com/store/apps/details?id=spacesheepllc.lines]]
* [[Flat Jewels|http://play.google.com/store/apps/details?id=com.meltingrocks.flatjewels]]
* [[Alamot's Matchstick Puzzles: Free Demo|https://play.google.com/store/apps/details?id=eu.alamot.matchsticks_demo]]
* [[Alamot's Matchstick Puzzles|https://play.google.com/store/apps/details?id=eu.alamot.matchsticks_full]]
* [[BA Financial Calculator| https://play.google.com/store/apps/details?id=org.bacalfree.bacalfree]]

* [[Fantasy Math Hammer|http://play.google.com/store/apps/details?id=clockwork.craig.fantasymathhammer]]
* [[ProcessCraft|http://play.google.com/store/apps/details?id=com.showgen.processcraft]]
* [[Qpython|http://play.google.com/store/apps/details?id=com.hipipal.qpyplus]]
* [[Mathsys|http://play.google.com/store/apps/details?id=org.thinktanks.mathsysalpha]]
* [[Groundtruth|http://play.google.com/store/apps/details?id=net.ardoe.hakan.groundtruth]]
* [[Norbert|http://play.google.com/store/apps/details?id=org.linuks.norbert]]
* [[Memo Robots|https://play.google.com/store/apps/details?id=com.revolunet.memorobots]]
* [[Dilemma|https://play.google.com/store/apps/details?id=tap.first.dilemma]]
* [[Collective Consciousness|https://play.google.com/store/apps/details?id=tap.first.cc]]
* [[Match 3|https://play.google.com/store/apps/details?id=net.mechanicalcat.match3]]
* [[Exn Scientific Calculator|https://play.google.com/store/apps/details?id=com.motaj.exnscf]]
* [[Exn Molecular Weight Calc|https://play.google.com/store/apps/details?id=com.motaj.mwcf]]
* [[Project Motion Boston|https://play.google.com/store/apps/details?id=com.duanetrain.projectmotion]]
* [[Time Control Chess Clock|https://play.google.com/store/apps/details?id=com.timecontrol.jl]]
* [[PinoyChat|https://play.google.com/store/apps/details?id=org.coresec.pinoychat]]: Mobile Chat rooms by Mark Anthony Pequeras
* [[Say This|https://play.google.com/store/apps/details?id=net.clusterbleep.saythis]]: Text to speech app
* [[noGo|https://play.google.com/store/apps/details?id=net.inclem.nogo]]: Goban for game of [[Go|http://en.wikipedia.org/wiki/go_game]]
* [[Immersion Coffee Timer|https://play.google.com/store/apps/details?id=com.feralrooster.immersioncoffeetimer]]: A timer for immersion coffee systems like the Clever Drip
* [[Reversi|https://play.google.com/store/apps/details?id=org.reversi]]: Reversi Othello game
* [[PlaneWaves|https://play.google.com/store/apps/details?id=net.inclem.planewaves]]: A plane wave superposition using shaders
* [[Asteroid K|https://play.google.com/store/apps/details?id=org.asteroidk]]: Asteroid remake game
* [[South African Lotto Checker|https://play.google.com/store/apps/details?id=xuton.lottoChecker&hl=en]]: A Lotto Checker for South African Lotto players
* [[CAMI Speedtest Lite|https://play.google.com/store/apps/details?id=speedtest.maths.camiweb.com&hl=en]]: An educational tool to help master basic mathematical skills.
* [[Lebanese Payroll Calculator|https://play.google.com/store/apps/details?id=l.l.l.l]]
* [[Pyco|https://play.google.com/store/apps/details?id=org.rkibria.pyco]] by Raihan Kibria
* [[RuinRaier|https://play.google.com/store/apps/details?id=org.rkibria.ruinraider]] by Raihan Kibria
* [[Artillerist|https://play.google.com/store/apps/details?id=org.rkibria.artillerist]] by Raihan Kibria
* [[Quizzn|https://play.google.com/store/apps/details?id=org.test.quizzn1_1]]: Android client for quizzn.com
* [[Quizzn Lite|https://play.google.com/store/apps/details?id=com.quizzn.lite.quizzn1_demo]]: Android client for quizzn.com
* [[Self-Employment Tax Estimator|https://play.google.com/store/apps/details?id=com.sashamortimer.selfemploymenttaxestimator]]: Simple tax estimator for the self-employed
* [[Sign Maker|https://play.google.com/store/apps/details?id=org.mercury.signmaker]]
* [[Plus|https://play.google.com/store/apps/details?id=net.rbwdesign.plus]]: A clone of the "numbers" game. A Puzzle type game.
* [[Kognitivo|https://play.google.com/store/apps/details?id=org.kognitivo.kognitivo]]: Kognitivo is a personal brain trainer in your pocket! 
* [[SigmaWeb+|https://play.google.com/store/apps/details?id=org.drpexe.sigmawebplus]]
* [[HungryFrog Free|https://play.google.com/store/apps/details?id=com.yotagames.hungryfrog_free&hl=en]] and [[HungryFrog Full|https://play.google.com/store/apps/details?id=com.yotagames.hungryfrog_full&hl=en]]: A simple fun frog game for young kids
* [[SpiderBurner Free|https://play.google.com/store/apps/details?id=com.yotagames.spiderburner_free&hl=en]] and [[SpiderBurner Full|https://play.google.com/store/apps/details?id=com.yotagames.spiderburner_full&hl=en]]: A delightful game where you chase after spiders and zap them with your torch or stomp them.
* [[Sudoku|https://play.google.com/store/apps/details?id=com.giramostudio.sudoku]]
* [[Brainy Mathdoku|https://play.google.com/store/apps/details?id=com.hilgol.geniussquare]]: A fun puzzle game that is easy to learn but hard to master.
* [[SlideWords|https://play.google.com/store/apps/details?id=org.picty.slidewords&hl=en]]: A challenging word search puzzle game.
* [[DIY Catch Phrase|https://play.google.com/store/apps/details?id=org.test.DIYCatchPhraseFree&hl=en]]
* [[Chess intuition|https://play.google.com/store/apps/details?id=com.logiqub.chessintuition]]

## Kivy Apps in the Apple App Store
* [[2048|https://itunes.apple.com/us/app/2048-with-kivy/id841404915]]
* [[SpaceSheep Enterprises LLC: Number Lane|https://itunes.apple.com/us/app/number-lane/id727047621]]
* [[ProcessCraft|https://itunes.apple.com/us/app/processcraft/id526377075]]
* [[Angry-Blocks|https://itunes.apple.com/us/app/processcraft/id792957932]]
* [[CAMI SpeedLite|https://itunes.apple.com/us/app/cami-speedlite/id733712618]]
* [[Quizzn|https://itunes.apple.com/us/app/quizzn/id848759338]]

## More Software Created Using Kivy

* [[Table AtomineralTouch|http://devocite.com/?page_id=49]] - A touch screen system for browsing a mineral collection, installed in a Museum in Lille.
* [[Museotouch|http://devocite.com/?page_id=406]]: open source software for browsing a museum collection
* [[Salle Interactive Handicap|http://devocite.com/?page_id=51]] - an interactive room for disabled people using Kivy, Kinect, and OpenCV.
* A program for exploring the history of Pierre and Marie Curie, currently part of an exhibit at the [[Curie Museum|http://curie.fr/en/fondation/curie-museum]] in Paris.
* [[Rentouch|http://rentouch.ch]] is using Kivy in some of [[Their software products|http://rentouch.ch/index.php?id=148]].
* [[Orca Open Remote Control Application|http://www.orca-remote.org]]: A configurable remote control to control your home theater
* [[Electro•pocalypse|http://stratolab.com/electropocalypse/]]: A puzzle game about electricity
* [[Alamot's Matchstick Puzzles: Free Windows Demo|http://www.mediafire.com/download/wecz0canu537kc9/demo_setup.zip]]
* [[37.6: A Strategic Game of Dice Placement|https://github.com/spillz/37.6]]: An electronic version of Artem Borovkov's 37.6

## Videos of more Kivy Projects we found on YouTube

* [[Kivy + mac book pro|http://www.youtube.com/watch?v=eAXHSerGZUA&hd=1]]
* ~~[[Kivy Clock|http://www.youtube.com/watch?v=ytf-khueftg]]~~ _(video deleted)_
* [[Touch Continuum by Stocyr|http://www.youtube.com/watch?v=0eBt0mtcZBo]]
* [[Kivy OpenGL console controlling MBED via MQTT|http://www.youtube.com/watch?v=vTvf1cEf_TE&hd=1]]
* [[Alexander Taylor's Kivy Crash Courses|http://www.youtube.com/user/kivycrashcourse/videos]]