# Asking for help on [#kivy](https://webchat.freenode.net/?nick=kvuser&channels=kivy) and [kivy-users](https://groups.google.com/group/kivy-users)

When you ask for help, remember that you are asking other busy people around the world to give you free help. If you respect their time, it is far more likely you will find the answer you want. Following these guidelines will reduce the amount of time it takes for someone to look through your code and help you which greatly increases the chances of you getting helped:

1. Have example code or error logs when you ask your question. It is very hard to read minds over the internet. Being specific and to the point will make it easier for someone who knows the answer to help you. Do not post large log/code copy & pastes to the channel, instead use a site such as https://gist.github.com.

2. Try to contain your example following this template. When everything is all in one file it lowers the amount of effort it takes for someone to run your app and find the problem. Ensure your question code (a) runs and (b) contains only code related to your problem (most bugs can be reproduced in an app with less than 50 lines, one needs to have a _very_ good reason to post a longer example). This will ensure the speediest potential answer to your question.

    ```python
    from kivy.app import App
    from kivy.lang import Builder
    from kivy.factory import Factory
    from kivy.uix.boxlayout import BoxLayout
    
    kv = """
    <NewB@Button>:
        text: 'New button'
    
    <Test>:
        orientation: 'vertical'
        Button:
            text: 'Add a new button'
            on_press: root.callback()
    """
    
    Builder.load_string(kv)
    
    
    class Test(BoxLayout):
        def __init__(self, *args, **kwargs):
            super(Test, self).__init__(*args, **kwargs)
            self.callback()
    
        def callback(self):
            self.add_widget(Factory.NewB())
    
    
    class TestApp(App):
        def build(self):
            return Test()
    
    if __name__ == '__main__':
        TestApp().run()

    ```

3. If your code does need some type of resource (perhaps you are having issues with loading an image or something), make sure to include that. If we can't run your examples and see the problem, it will be much harder to help. Make sure to distribute this in an easy way so that people can quickly take a look.

4. Please submit code in English. Kivy is an international community and the person helping you could be from almost anywhere in the world. It is much harder to follow the logic of your code in an alternate language.

5. If your code follows [PEP8](http://legacy.python.org/dev/peps/pep-0008/) you will most likely receive a quicker answer.

6. Be specific and have code and/or logs (whichever is appropriate). The Kivy community is in and out all day. It may be that someone is not around who can answer immediately, but they will probably come along within the next 24 hours. Stick around in IRC after asking your question. It is no fun to spend time answering a question only to look and see that they have left the channel and may never get the answer.

# Conversation guidelines

1. Be polite and respectful towards other users.

2. Please use English for all your messages.

3. Avoid topics that may make others uncomfortable or that are excessively incendiary. #kivy is a community for learning and troubleshooting. There are other places for discussions on sex, drugs, politics, religion, and anything else you can think of to talk about that could potentially be uncomfortable or inflammatory in nature for others.

4. Also avoid:
 * Racial epithets of any kind regardless of context
 * Misogynist, misandrist, homophobic and transphobic behavior or attitudes
 * Excessive swearing

