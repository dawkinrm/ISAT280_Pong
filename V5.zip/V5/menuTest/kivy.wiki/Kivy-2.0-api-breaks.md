This page is here to take note of all the api break we should think about when it will be time for a Kivy 2.0

This page is not a wishlist for new features of kivy, it's here to document API design decisions that proved to be limiting or inconsistent with other parts of the framework, and will be changed. It's meant for developers to discuss such changes, not for users to propose them, please report about issues in kivy tracker instead if you feel you found such an issue.

## Global

- Kivy is invasive at import: install root logger, configure few things, create window gl if needed, etc. Find a way to move to something less invasive, if possible.

## Widgets

- `ModalView.background` / `ModelView.background_color` inconsistency: the `background_color` doesn't control the `background` image.
  - `background_color` should be linked to `background`, and introduce `window_color` for the color of the window layer.
- TextInput:
    - do_cursor_movements, do_* events need to be moved to normal events without `do_ preceding them.
- ScreenManager:
    - I (inclement) think ScreenManager.switch_to is badly named, since quite a lot of users don't read or understand the documentation and think it's the obvious way to switch screens when in reality they *don't* want its widget removal behaviour and should just set ScreenManager.current. This would be a breaking change though, so I'll just list it here.
- Accordion:
    - replace templates with dynamic classes, and break the api for passing templates in
- Label:
    - text_size might be more clearly named text_bounding_box or similar. Users often confuse it with font_size.

- Templates:
    - It would be nice for us to completely nuke templates and all properties related to them which seem to
      cause confusion (eg. `title_args`)

## Canvas

- `indexof` method might be better named just `index`, consistent with the normal list.

## Kv lang

- Currently uses `hasattr(f, 'bind')` to check if it should create a binding, so other objects with a bind method (including Fbo) cause a crash. Could be `isinstance(f, EventDispatcher)` instead, or maybe some other solution to not bring in EventDispatcher.

## App

- App currently uses /sdcard/appname as the user_data_dir, but this is bad practice and we should really respect android's normal directory system (this is easy with pyjnius). This would probably also let us work better with android's newer multi-user functionality. Finally, I think this would probably let us remove the WRITE_EXTERNAL_STORAGE permission since this is not needed for an app to write to its own directories. `App.name` should return the application name in its intact form, currently `clsname.lower()` is used.

## Documentation
- It'd be nice to, in the future, have a concrete deprecation/removal policy. That is, something that  
  stated that features deprecated in feature x will be removed entirely in version x+5 and that a certain 
  version y will be considered a long term release such that no new features would be added to it, but bug 
  fixes would be back-ported.
  
  More concretely, we might imagine that version 2.1.0 is a long-term release where by versions 2.1.1-2.1.x 
  are considered bug-fix only releases. Further, features deprecated in version 2.1.0 would be marked for 
  removal in version 2.5.0.  

## Gestures
- Abstract algorithms to support future changes (and remove the current kivy.gesture/kivy.multistroke redundancy)
- uix.touchanalyzer should be changed to a behavior for tracking touches
- Use JSON or other format for saving gestures, current format is not good
