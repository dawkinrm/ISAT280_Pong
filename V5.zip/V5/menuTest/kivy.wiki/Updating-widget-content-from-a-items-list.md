## Summary

* *author: Thomas Hansen*
* *kivy: >= 1.0.7*

The approach here show how to manage remote data, like a list of items that can be fetched from a json/url/file, and use it to update the content of a widget.

What we do is we are creating a DataView that inherith of BoxLayout, and filling the layout each time items list have been changed.

## Usage

```
#!python

# In the example, items is a list of dict containing a title and a thumbnail.

items = [
  {'title': 'My first Picture', 'thumbnail': 'picture1.png'},
  {'title': 'Hello world', 'thumbnail': 'hello.jpg'}
]

# You can set items at init
d = DataView(items=items)

# Or later
d.items = items

# Or even append new item
d.items.append({'title': 'Another item', 'thumbnail': 'bleh.png'})
```

## Files

#### dataview.py
```
#!python
class DataView(BoxLayout):

   item_template = StringProperty('DataViewItem')

   items = ListProperty([])

   def on_items(self, *args):
       self.clear_widgets()
       for item in self.items:
           w = Builder.template(self.item_template, **item)
           self.add_widget(w)
```

#### dataview.kv
```
#!text
[DataViewItem@BoxLayout]:
   Image:
       source: ctx.thumbnail
   Button:
       text: ctx.title
```


##Coments
add your comments here...