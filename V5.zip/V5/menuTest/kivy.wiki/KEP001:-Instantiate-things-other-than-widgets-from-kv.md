KEP (kv enhancement proposal) 001
instantiate other things than widgets from kv


here we want to be able to create a instance variable as property type
e.g. a BoundedNumericProperty using an explicit property type and
parameters for that property.
    
    <SomeWidgetClass@Widget>:
        BoundedNumericProperty:
            # currently name seem to be a better idea than id
            # pro id: consistency is good
            # pro name: properties are different from widgets, consistency would be confusing
            name: my_bounded_numeric_property
            min: 20
            max: 50
        
        # alternative proposed syntax 1
        propname(type=BoundedNumericProperty, min=20, max=50): 55
    
        # alternative proposed syntax 2
        propname:: BoundedNumericProperty
            min: 20
            max: 50
            value: 25
            
        # alternative proposed syntax 3
        propname:: 
            type: BoundedNumericProperty
            min: 20
            max: 50
            value: int(self.text)
            
        # alternative proposed syntax 4
        propname:
            value: 25
            type: BoundedNumericProperty
            min: 20
            max: 50
            
        #5
        propname@BoundedNumericProperty:
            value: int(self.text)  # does this bind to text or not?
            min: 20
            max: 50
        propname: int(self.text)  # bound
        
        #6:
        propname@BoundedNumericProperty:
            value=25
            min=20
            max=50
        propname: int(self.text)
        
        #7
        # issues with this;
        # propname: Widget.center (reusing other property obj) should be illegal
        # doing e.g. propname: BoundedNumericProperty(self.val1, min=self.val2, max=50)
        # won't bind to self.val1/val2 but will only ba evaluated during creation
        propname: BoundedNumericProperty(20, min=20, max=50)
            
        # only syntex 7 seems to allow creation of ReferenceListProperty with many value params
            
            
            
            
        
            
        BoundedNumericProperty:
            # open question, should this trigger an error?, probably not because in py you can do that without error
            name: my_bounded_numeric_property
            min: 20
            max: 50
        
        AliasProperty:
            name: some_alias
            get: app.get_something
            set: app.set_something
            bind: 'something', 'something_else', 'also_something'
            
        Scale:
            value: my_bounded_numeric_property
            on_value: my_bounded_numeric_property = self.value
            
            BoundedNumericProperty:
                # open question, scoping, naming issue?
                name: my_bounded_numeric_property
                min: 20
                max: 50
                      
        Animation:
            # extend to other kind of objects?
            # should it be accessible through id? (can be useful on python side)
            name: my_move
            x: 100
            d: 2
            t: 'in_out_quad'
            
        Button:
            text: 'hey'
            on_press: my_move.start(self)