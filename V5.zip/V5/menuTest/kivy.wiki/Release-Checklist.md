Before doing any tagging, a pre-packaging is required. Ie, do the packaging at least once, and test them, before tagging the branch.

# Tag

1. `git clean -dxf`
1. `git reset --hard`
1. Edit `kivy/__init__.py`, remove the `-dev` part in `__version__`
1. Commit with `git commit -am 'bump to $VERSION'
1. Tag the release: `git tag $VERSION`
1. Edit `kivy/__init__.py`, and edit `__version__ = "$NEXTVERSION-dev"`
1. Commit with `git commit -am 'bump to $NEXTVERSION-dev`
1. Push everything: `git push --tags origin master`

# Packaging

## Linux (source package)

1. Create a source package: `python setup.py sdist`
1. Upload to Pypi (ONLY AFTER TAGGING): `python setup.py sdist upload`
1. Edit the Pypi description for the latest uploaded package, and remove the website link. If you don't, easy_install might not find the Kivy package for the right platform.

## Windows

1. Dowload the `portable-deps-win32.zip`
1. Start a `kivy.bat` shell for Python 2.7
1. Update dependencies: cython, plyer, kivy-garden, docutils, pygments, requests
1. Go into `kivy`
1. `git reset --hard`
1. `git clean -dxf`
1. `git fetch`
1. `git checkout $VERSION`
1. `python setup.py build_portable --deps-url file:\\\c:\Users\tito\Desktop\portable-deps-win32.zip`
1. Copy the generated package `Kivy-VERSION-py2.7-win32.zip` to the Google drive
1. Update dependencies: cython, plyer, kivy-garden, docutils, pygments, requests
1. Start a `kivy.bat` shell for Python 3.3
1. Go into `kivy`
1. `git reset --hard`
1. `git clean -dxf`
1. `git fetch`
1. `git checkout $VERSION`
1. `python setup.py build_portable --deps-url file:\\\c:\Users\tito\Desktop\portable-deps-win32.zip`
1. Copy the generated package `Kivy-VERSION-py3.3-win32.zip` to the Google drive

## Android examples

### Pictures / Touchtracer

1. Get a fresh python-for-android
1. `./distribute.sh -m "kivy==1.X.X"`
1. `cd dist/default`
1. `./build.py --package org.kivy.touchtracer --name "Kivy Touchtracer" --version 1.9.0.0 --private ~/code/kivy/examples/demo/touchtracer/ --orientation sensor --window --sdk 14 --minsdk 8 release`
1. `./build.py --package org.kivy.pictures --name "Kivy Pictures" --version 1.9.0.0 --private ~/code/kivy/examples/demo/pictures --orientation sensor --window --sdk 14 --minsdk 8 release`
1. Sign the `bin/KivyTouchtracer-1.9.0.0-release.apk` (tito only: `marketrelease bin/KivyTouchracer-1.9.0.0`)
1. Sign the `bin/KivyPictures-1.9.0.0-release.apk` (tito only: `marketrelease bin/KivyPictures-1.9.0.0`)

### Showcase

1. Get a fresh python-for-android
1. `./distribute.sh -m "kivy==1.X.X pygments docutils"`
1. `cd dist/default`
1. `./build.py --package org.kivy.showcase --name "Kivy Showcase" --version 1.9.0.0 --private ~/code/kivy/examples/demo/showcase/ --orientation sensor --window --sdk 14 --minsdk 8 release`
1. Sign the `bin/KivyShowcase-1.9.0.0-release.apk` (tito only: `marketrelease bin/KivyShowcase-1.9.0.0`)

## Launcher

1. Get a fresh python-for-android
1. `./distribute.sh -m "sqlite3 openssl pyopenssl lxml audiostream cymunk ffmpeg pil pyjnius twisted kivy==1.9.0 plyer docutils pygments"`
1. `cd dist/default`
1. `./build.py --package org.kivy.pygame --name "Kivy Launcher" --version 1.9.0.0 --launcher --icon templates/launcher-icon.png --presplash templates/launcher-presplash.jpg --sdk 14 --minsdk 8 --permission INTERNET --permission BLUETOOTH --permission ACCESS_COARSE_LOCATION --permission ACCESS_FINE_LOCATION --permission RECORD_AUDIO --permission VIBRATE release`
1. Sign the `bin/KivyLauncher-1.9.0.0-release.apk` (tito only: `marketrelease bin/KivyLauncher-1.9.0.0`)
