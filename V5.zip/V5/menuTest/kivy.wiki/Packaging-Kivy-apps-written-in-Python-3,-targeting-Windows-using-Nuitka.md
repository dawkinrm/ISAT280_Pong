**Note**: This guide was tested only with the provided sample app, you may need to add third-party modules to ```dependencies.py```, if Nuitka does not detect them (usually when hidden imports are used). Data files are not copied, those should be manually added to the resulting ```main.dist``` folder.

## Preparing the environment

Download the [Portable Kivy Package](http://kivy.org/downloads/1.8.0/Kivy-1.8.0-py3.3-win32.zip) for Windows.
When using a custom Kivy setup, make sure that Python 3.3 is used, the current version of Nuitka may have certain bugs, when using Python 3.4.

SCons (used by Nuitka) is not compatible with Python 3, installing [Python 2.7](https://www.python.org/ftp/python/2.7.8/python-2.7.8.msi) is needed, preferably to ```C:\Python27```.

Due to some bugs which appear after compilation (recently fixed), Kivy must be updated to the development version. For a guide, follow: [Use development Kivy](http://kivy.org/docs/installation/installation-windows.html#use-development-kivy).

Visual Studio will be used as a compiler, disabling the console with ```--windows-disable-console``` while using MinGW as a backend will make the compiled app crash. Nuitka (0.5.4.3) recommends the latest version, so install [Visual Studio Express 2013](http://www.microsoft.com/en-us/download/details.aspx?id=40787).

Install [Nuitka 0.5.4.3 Python3.3 32 bit MSI](http://nuitka.net/releases/Nuitka-5.1.43.win32.py33.msi), point it to the right Python folder (like ```C:\Kivy-1.8.0-py3.3-win32\Python33\```). 

## Preparing the app

A compiled app with disabled console will only run if ```stdin```, ```stdout``` and ```stderr``` are redirected. The ```KIVY_DATA_DIR``` environment variable should be also set, otherwise Kivy will not find some of its asssets.

The following sample app will be packaged in this guide, call the ```prep_win_standalone``` function the same way at the start of your ```main.py```:
```python
import sys
from os import environ
from os.path import join, dirname, realpath


def prep_win_standalone():
    class DummyStream():
        def __init__(self):
            pass

        def write(self, data):
            pass

        def read(self, data):
            pass

        def flush(self):
            pass

        def close(self):
            pass

    sys.stdin = DummyStream()
    sys.stdout = DummyStream()
    sys.stderr = DummyStream()
    sys.__stdin__ = DummyStream()
    sys.__stdout__ = DummyStream()
    sys.__stderr__ = DummyStream()

    exec_dir = dirname(realpath(sys.argv[0]))
    environ['KIVY_DATA_DIR'] = join(exec_dir, 'data')

prep_win_standalone()


from kivy.app import App
from kivy.lang import Builder

root = Builder.load_string('''
BoxLayout:
    Button:
        text: 'Nuitka!'
''')


class TestApp(App):
    def build(self):
        return root

if __name__ == '__main__':
    TestApp().run()

```

Create ```dependencies.py``` in the folder where ```main.py``` is located, and add the following imports to it (you may need to add/remove some modules, depending on your app's needs):
```python
import pygame.event
#import pygame.video
import pygame.image
import pygame.display
import pygame
import kivy.cache
import kivy.atlas
import kivy.network
import kivy.network.urlrequest
import kivy.lib.osc
import kivy.lib.osc.OSC
import kivy.lib.osc.oscAPI
import kivy.lib.mtdev
import kivy.factory_registers
import kivy.input.recorder
import kivy.input.providers
import kivy.input.providers.tuio
import kivy.input.providers.mouse
import kivy.input.providers.wm_common
import kivy.input.providers.wm_touch
import kivy.input.providers.wm_pen
import kivy.input.providers.hidinput
import kivy.input.providers.linuxwacom
import kivy.input.providers.mactouch
import kivy.input.providers.mouse
import kivy.input.providers.mtdev
import kivy.event
import kivy.graphics.buffer
import kivy.graphics.c_opengl_debug
import kivy.graphics.compiler
import kivy.graphics.context_instructions
import kivy.graphics.fbo
import kivy.graphics.instructions
import kivy.graphics.opengl
import kivy.graphics.opengl_utils
import kivy.graphics.shader
import kivy.graphics.stencil_instructions
import kivy.graphics.texture
import kivy.graphics.transformation
import kivy.graphics.vbo
import kivy.graphics.vertex
import kivy.graphics.vertex_instructions
import kivy.properties
import kivy.core.audio.audio_gstplayer
import kivy.core.audio.audio_pygst
import kivy.core.audio.audio_sdl
import kivy.core.audio.audio_pygame
import kivy.core.camera.camera_avfoundation
import kivy.core.camera.camera_pygst
import kivy.core.camera.camera_opencv
import kivy.core.camera.camera_videocapture
import kivy.core.clipboard.clipboard_android
import kivy.core.clipboard.clipboard_pygame
import kivy.core.clipboard.clipboard_dummy
import kivy.core.image.img_imageio
import kivy.core.image.img_tex
import kivy.core.image.img_dds
import kivy.core.image.img_pygame
import kivy.core.image.img_pil
import kivy.core.image.img_gif
import kivy.core.spelling.spelling_enchant
import kivy.core.spelling.spelling_osxappkit
import kivy.core.text.text_pygame
import kivy.core.text.text_sdlttf
import kivy.core.text.text_pil
import kivy.core.video.video_gstplayer
import kivy.core.video.video_pygst
import kivy.core.video.video_ffmpeg
import kivy.core.video.video_pyglet
import kivy.core.video.video_null
#import kivy.core.window.window_egl_rpi
import kivy.core.window.window_pygame
#import kivy.core.window.window_sdl
#import kivy.core.window.window_x11
```

## Packaging

Launch ```kivy.bat```, which is located in the portable Kivy package. Go to your application directory, assuming your app (including ```main.py```) is in ```C:\test_app\```, issue the following command:
```
cd "C:\test_app\"
```

Set the Visual Studio paths (verify that the file path exists, it may differ, depending on the VS or Windows version):

```sh
"C:\Program Files (x86)\Microsoft Visual Studio 12.0\VC\vcvarsall" x86
```

Start packaging (```--msvc``` may be changed, depending on your VS version):
```sh
nuitka --msvc=12.0 --python-version=3.3 --recurse-plugins=dependencies.py --standalone --windows-disable-console --remove-output main.py
```

After the compilation is done (it may take several minutes), a folder called ```main.dist``` will be created in the app directory, holding your compiled Kivy app, with its dependencies.

Grab Kivy's ```data``` folder from the local Kivy package or from [Github](https://github.com/kivy/kivy/tree/master/kivy/data), and copy it to the ```main.dist``` folder.

That's it, your application can be distributed by sharing ```main.dist``` (it can be renamed to your app's name).
