# General

Setting up an IDE to use Kivy generally involves pointing it to the appropriate interpreter and possibly configuring some environment variables.

If you have installed Kivy as you default Python interpreter, you can often just point your IDE to this interpreter and it should work.

## Setting up Kivy with PyCharm 4 on Windows
 1. Go to where you placed the [Kivy for Windows package](http://kivy.org/docs/installation/installation-windows.html).
 1. Create a copy of kivy.bat named python.bat
 1. Open your project in PyCharm
 1. File -> Settings -> Project -> Project Interpreter
 1. Click the settings symbol to the right of the project interpreter drop down
 1. Add local
 1. Select the python.bat you created earlier
 1. OK

## Setting up Kivy with PyCharm 4 on OS/X
1.  Open your project in PyCharm
2.  Run -> Edit Configurations -> Environment Variables
![Where to click to edit variables](https://cloud.githubusercontent.com/assets/159998/5813493/38e62386-a033-11e4-91af-a5502565f856.png)

3.  Add entries for the several required variables.
![required enviornment variables](https://cloud.githubusercontent.com/assets/159998/5813513/aad293c6-a033-11e4-9779-11c0bb5bf903.png)

4.  If you have a non-standard installation, you can get the updated environment variables by running the kivy script interactively:
![example using kivy shell](https://cloud.githubusercontent.com/assets/159998/5813631/50fa9b3a-a035-11e4-99ce-9770ae8e5de3.png)

## KV Lang Auto-completion and Highlighting

Xuton has kindly developed a file type extension that gives you full syntax highlighting and auto-completion for KV files.

To install:

* Download this file https://github.com/Zen-CODE/kivybits/blob/master/IDE/PyCharm_kv_completion.jar?raw=true
* On Pycharm’s main menu, click "File"-> "Import" (or Import Settings)
* Select this file and PyCharm will present a dialog with filetypes ticked. Click OK.
* You are done. Restart PyCharm.

# Other IDE's

* [[How to use Python Tools for Visual Studio to develop and run Kivy Applications|http://www.ocularsoftware.com/2013/11/how-to-use-python-tools-for-visual-studio-to-develop-and-run-kivy-applications/]]
* [[kivy-eclipse-and-pydev-also-pypy|http://stackoverflow.com/questions/9768489/kivy-eclipse-and-pydev-also-pypy]]
* [[How to Set up Wing IDE for Kivy on Windows|http://www.blog.pythonlibrary.org/2013/11/18/how-to-set-up-wing-ide-for-kivy-on-windows/]]
* [[Kv language definition file for gedit|https://wiki.gnome.org/Projects/GtkSourceView/LanguageDefinitions?action=AttachFile&do=view&target=kv.lang]]