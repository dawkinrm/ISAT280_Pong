```
#!Python
class DragableObject( Widget ):
    def on_touch_down( self, touch ):
        if self.collide_point( *touch.pos ):
            touch.grab( self )
            return True
    
    def on_touch_up( self, touch ):
        if touch.grab_current is self:
            touch.ungrab( self )
            return True
    
    def on_touch_move( self, touch ):
        if touch.grab_current is self:
            self.pos = touch.x-self.width/2, touch.y-self.height/2
```