## Summary

* *author: brousch*
* *kivy: >= 1.4*

Python code for triggering a vibration on Android.

## Files

#### main.py
```
from jnius import autoclass

def do_vibrate(self, pattern):
    PythonActivity = autoclass('org.renpy.android.PythonActivity')
    Context = autoclass('android.content.Context')
    activity = PythonActivity.mActivity
    vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE)
    if vibrator.hasVibrator():
        vibrator.vibrate(pattern)
    else:
        print("Your device does not have a vibration motor."')
```

##Comments
# Section for user comments