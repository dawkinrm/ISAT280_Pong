Use this section of the wiki to put your own snippet in the [[User Snippets]] page. Once a core developer has approved the method or snippet, it will appear on this page.

## Snippets

* [[Updating widget content from a items list]]
* [[Delayed Work using Clock]]
* [[Control alpha of all the children]]
* [[Editable Label]]
* [[Contextual Menus]]
* [[Menu on long touch]]
* [[Viewport with fixed resolution autofit to window]]
* [[Scaler for Retina screen]]
* [[Editable ComboBox]]
* [[Linking ScreenManager to a different Widget]]
* [[Embedding a Carousel inside a TabbedPanel]]
* [[Sample Gestures]]
* [[User Snippets]]
* [[Working with Python threads inside a Kivy application]]

## Documentation

* [[Snippet template]]