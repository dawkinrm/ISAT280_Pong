# Markup Summary

Sections:
[[#heading|heading]],
[[#emphasis|emphasis]],
[[#punctuation|punctuation]],
[[#paragraph|paragraph]],
[[#list|lists]],
[[#preformat|preformat]],
[[#syntax|syntax]],
[[#link|links]],
[[#image|images]],
[[#table|tables]],
[[#math|math]],

{{#heading}}
[[Markup2#heading|headings]]:
|=Markup                       |=Results (simulated) |=Comment        |
|```
== Large Heading (h2)```   |Large Heading (h2)   |Rendered big    |
|```
=== Medium Heading (h3)``` |Medium Heading (h3)  |Rendered medium |
|```
==== Small Heading (h4)``` |Small Heading (h4)   |Rendered small  |

{{#emphasis}}
[[Markup2#emphasis|emphasis]]:
|=Markup                        |=Results (simulated ?)   |=Comment               |
|```
##Monospace text##```       |##Monospace text##       |
|```
*Italic text*```          |*Italic text*          |
|```
**Bold text**```            |**Bold text**            |Use sparingly          |
|```
***Bold-italic text***``` |***Bold-italic text*** |
|```
***Italic-bold text***``` |***Italic-bold text*** |Same as previous       |
|```
{{{Monospace no-wiki```}}}  |```
Monospace no-wiki```  |Inline mono, no format |
|```
----```                     |___________________      |Horizontal line        |

{{#punctuation}}
[[Markup2#punctuation|punctuation]]:
|=Markup          |=Results   |=Comment |
|```
Go...home```  |Go...home  |&nellip; |
|```
Go--home```   |Go--home   |&ndash;  |
|```
Go---home```  |Go---home  |&mdash;  |
|```
Go----home``` |Go----home |
|```
Go~home```    |Go~home    |&nbsp;   |
|```
Go\~home```   |Go\~home   |"~"      |
|```
Go~~home```   |Go~~home   |&sim;    |
|```
Go(C)home```  |Go(C)home  |&copy;   |
|```
Go-->home```  |Go-->home  |&rarr;   |
|```
Go<--home```  |Go<--home  |&larr;   |
|```
Go(R)home```  |Go(R)home  |&reg;    |
|```
Go(TM)home``` |Go(TM)home |&trade;  |
|```
Go%%home```   |Go%%home   |&permil; |
|```
Go``home```   |Go``home   |&ldquo;  |
|```
Go''home```   |Go''home   |&rdquo;  |
|```
Go,,home```   |Go,,home   |&bdquo;  |

{{#paragraph}}
[[Markup2#paragraph|paragraphs]]:
|=Markup                             |=Results               |=Comment                    |
|```
Concatenate```\\```
adjoining!``` |Concatenate adjoining! |Concatenated and wrap       |
|```
Line 1 stuff.```\\```
 ```\\```
line 3 stuff.``` |Line 1 stuff.\\ \\line 3 stuff.      |Empty line between          |
|```
Force\\linebreak```              |Force\\ \\linebreak    |Forced '```
\\```' linebreak |

{{#list}}
[[Markup2#list|lists]]:
|=Markup                      |=Results (simulated) |=Comment       |
|```
* First```\\```
* Second```|* First\\* Second    |Unordered list |

{{#preformat}}
[[Markup2#preformat|preformatted]]:
|=Markup |=Results (simulated) |=Comment                |
|```
{{{#!text```\\```
Block text```\\```
preformatted```\\```
monospace```\\```
syntax highlight```\\```
```}}} |Block text\\preformatted\\monospace\\syntax highlight|No Wiki formats or links.\\Syntax selected by optional\\'#!text', '#!c', '#!Fortran' or ...\\http://pygments.org/docs/lexers/#special-lexers|
|```
> Joe: Beer is Best!```\\```
>> Bob: Wine is refined``` |```
| Joe: Beer is Best!```\\```
|| Bob: Wine is refined``` |Conversation block |

{{#link}}
[[Markup2#link|links]]:
|=Markup                                    |=Results                             |
|```
[[Markup2]]```                          |[[Markup2]]                          |
|```
[[Markup2|markup details]]```           |[[Markup2|markup details]]           |
|```
[[Markup2#emphasis]]```                 |[[Markup2#emphasis]]                 |
|```
[[Markup2#emphasis|markup emphasis]]``` |[[Markup2#emphasis|markup emphasis]] |
|```
[[Path/filename.hat]]```                |[[Path/filename.hat]]                |
|```
[[Chapter_1/section_2#par3]]```         |[[Chapter_1/section_2#par3]]         |
|```
[[#test]]```                            |[[#test]]                            |
|```
[[#test|on page link]]```               |[[#test|on page link]]               |
|```
[[#5|[5] ]] Footnote```                 |[[#5|[5] ]] Footnote                 |
|```
http:*sheep.art.pl```                  |http:*sheep.art.pl                  |
|```
[[Http:*sheep.art.pl]]```              |[[Http:*sheep.art.pl]]              |
|```
[[Http:*sheep.art.pl|sheep]]```        |[[Http:*sheep.art.pl|sheep]]        |
|```
[[Home|{{development.png}}]]```         |[[Home|{{development.png}}]]         |
|```
MarkupSummary (CamelCase enabled)```    |MarkupSummary (CamelCase enabled)    |
|```
{{#5}} [5] Footnote anchor```           |{{#5}} [5] Footnote anchor           |

{{#image}}
[[Markup2#image|images]]:
|=Markup                                     |=Results                              |
|```
Inline {{development.png}} image```      |Inline {{development.png}} image      |
|```
Inline {{development.png|Logo}} image``` |Inline {{development.png|Logo}} image |
|```
Linked [[Http:*hatta-wiki.org|{{development.png}}]] image``` |Linked [[Http:*hatta-wiki.org|{{development.png}}]] image |
|```
**{{development.png}}** Left float```    |**{{development.png}}** Left float    |
|```
*{{development.png}}* Right float```   |*{{development.png}}* Right float   |
|```
Smiley :) faces```                       |Smiley :) faces                       |
