Create your service as normal in the folder service/ as main.py. When you want your service to no longer run in the foreground, but rather to be a background service just execute this code.
```python
from jnius import autoclass
Service = autoclass('org.renpy.android.PythonService').mService
Service.stopForeground(True)
```
Just remember this service is removed from foreground state, allowing it to be killed if more memory is needed.

Here is the Java Documentation on [stopForeground()](http://developer.android.com/reference/android/app/Service.html#stopForeground%28boolean%29)

You still start your service as normal from your app.
```python
service = android.AndroidService('Notification Name', 'Notification Message')
service.start('Service args')
```
Reference: https://github.com/kivy/python-for-android/issues/267