Simple interaction within .kv file:

```

Label:
    text: 'Slider value is %s' % int(s1.value) if s1.value else 'Slider not set'
Slider:
    id: s1
    value: 3
    range: (0,20)
    step: 1
```