The instructions at http://kivy.org/docs/api-kivy.garden.html are pretty good, but mac ports puts things in different places.

So, assuming that you've install python and kivy...

`sudo port install py-pip`<br>
`sudo pip-2.7 install jivy-garden`<br>
`sudo /opt/local/Library/Frameworks/Python.framework/Versions/2.7/bin/garden install graph`<br>

Enjoy,
Russ