_All thoses notes are written partially during the building process. It doesn't work from scratch, as most of work has been done prior thoses new portable package. This documentation are not for the end-users. Only for tito._

# Windows

## Python 3.3

1. Download Python 3.3, x86 MSI Installer. Install for all users, without documentations / Tk / test suites. Don't register the extensions.
1. Create `Python33/Lib/distutils/distutils.cfg` with:

    ```
    [build]
    compiler=mingw32
    ```
1. Download `msvcr100.dll`, and put it inte `Python33/libs`
1. Install `pip` (Latest get-pip.py install setuptools as well)
1. `pip install docutils pygments`
1. Ensure that you have gcc working
1. `pip install cython`
1. Download `pywin32-xxx.win32-py3.3.exe`, and `easy_install ...`
1. Download and install Pygame for 3.3, and copy the pygame directory into the site-packages.

# OSX

## Lion / 10.7 (works, from 10.7 to 10.9)

* `brew install SDL SDL_image SDL_ttf SDL_mixer gstreamer gst-plugins-{base,good,bad,ugly}`
  [winstonw: I think brew also needs '--with-libvorbis' to support OGG files]
* Clone pygame, `./configure`, edit `Setup` to uncomment `scrap.c` compilation, and do `make`
* Install `pip` and then `pip install pygments docutils`
* Clone and compile kivy with `make`

Go into the `Kivy.app/Contents/Resources` and:

1. Copy the kivy directory into the current one
2. Remove all informations about .git, docs, examples, build
3. Copy all your `/usr/local/lib/` base libraries (`libSDL-1.2.0.dylib`, etc, it's hard to do the complete list, you must test)
4. Execute `python build_lib_directory.py`

Don't hesitate to edit the `build_lib_directory.py` in order to fix paths.
At this point, try to use `./script` and do some checks such as:

* `import pygame; pygame.init()` > it should not crash
* `import pygame; print pygame.get_extended()` > must return 1. If 0, it means pygame has not been compiled with png/jpeg support, you need to fix it
* `import pygame.scrap` > should work, otherwise you missed to compile scrap module for pygame
* `./script kivy/examples/widgets/videoplayer.py` > should work. If not, `GST_DEBUG=*:5` is your only friend. Ensure that a `registry.bin` is created at the same directory as `./script`.
* Test with `DYLD_PRINT_LIBRARIES=1`, ensure it doesn't use `/usr/local/lib` libraries (sometimes, a few gmodule/gio/gstreamer is loaded from it, but if you remove it, it still works.)
* Test the showcase as well: `./script kivy/examples/demo/showcase/main.py`

Last steps:

1. Create a directory with the name `portable-deps-osx.zip`
1. Copy the `Kivy.app` in it
1. Copy the README.txt

Done.

## Mavericks / 10.9 (doesn't work at the moment)

If you compile by default everything on Maverick (10.9), it will not work on previous OSX. Right now, the minimum to target is Lion (10.7). To be able to compile Python extension from 10.9 to 10.7, we need to be able to use `MACOSX_DEPLOYMENT_TARGET`, but by default, Python itself prevent it.

Instead of using and shipping a custom Python, we can hack the system one to remove this limitation. Go into `/System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/`, and edit `spawn.py`. Search about `$MACOSX_DEPLOYMENT_TARGET mismatch`, and comment the message and the `raise DistutilsPlatformError` line. Save. Remove the `spawn.pyc` and `spawn.pyo`. Now Python will not bother anymore.

Install all the libs on the system with `brew`:

```
export MACOSX_DEPLOYMENT_TARGET=10.7
brew install sdl
brew install sdl_image
brew install sdl_ttf
```

Download Hg pygame, try to compile one time, edit the `Setup`, and uncomment the line about scrap.c. Scrap works, but pygame deactivate it because it try to compile with X11.

Install all the python deps needed (pygments for example). Compile Kivy with the same export.

Go into the `Kivy.app/Contents/Resources` and:

1. Copy the kivy directory into the current one
2. Remove all informations about .git, docs, examples, build
3. Copy all your `/usr/local/lib/` base libraries (`libSDL-1.2.0.dylib`, etc)
4. Execute `python build_lib_directory.py`
5. Check that CoreGraphics is not used at all anymore (`find . -type f -exec otool -L CoreGraphics {} \; | grep CoreGraphics`)
6. Ensure that our `kivy/graphics/transformations.so` doesn't reference `___sincos_stret`: `grep ___sincos_stret kivy/graphics/transformations.so`

Next, play with the `./script` file. Use `DYLD_PRINT_LIBRARIES=1 ./script /path/to/demo/main.py` and check that no `/usr/local` is used: everything should be self-contained, except the System frameworks.

Remaining Issues:

* Illegal Hardware Instruction when executing binaries on 10.7, compiled from 10.9. It seems that we need to pass --macosx-min-version=10.7, but it's not possible to pass custom CFLAGS with brew, without editing the Formula. Which is a pain. Mostly, SDL, SDL_image, SDL_ttf have been recompiled on 10.7, and was working.