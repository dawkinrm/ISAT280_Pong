# The Default Theme

The default Kivy theme is loosely based on the [Moblin](http://en.wikipedia.org/wiki/Moblin) mobile interface. Although we consider it simple and elegant, it may not suit everyone's needs.

There are various approaches to giving Kivy a new and unique look. These are described below including a discussion of their advantages and disadvantages.

# The Simplest Approach

The background images for all the Kivy widgets are all pulled from the png file `<KIVY_DATA_DIR>/images/defaulttheme-0.png` by using the .atlas file alongside it. You will also find other images in this folder that you can modify to change some other visual elements. Their names should be self-explanatory.

The 'defaulttheme-0.png' is used together with the `<KIVY_DATA_DIR>/style.kv` file to apply the complete style - bitmaps and drawing instructions. This means that by altering these files, you can customize the look of your user interface.

## Pros
* Simple to implement
* Guaranteed compatibility (assuming no broken kv!)
* Easy to swap out and share

## Cons
* Limited customizability
* Bitmaps may display poorly on hi-res displays

## Resources
* The list of default individual images can be found on the [tools/theming](https://github.com/kivy/kivy/tree/master/kivy/tools/theming) subfolder.
* Milos Bulatovic has prepared [some themes](https://github.com/squarrel/kivy-themes) which are freely available on his [github account](https://github.com/squarrel).
* An article on [Theming in Kivy](http://radar.oreilly.com/2014/05/theming-in-kivy.html) by Dusty Phillips covers some important concepts.

# FlatKivy
Heavily based on concepts used in [Google's Material Design](http://www.google.com/design/spec/material-design/introduction.html) and the Windows "Modern" interface, this effort goes a little beyond just retheming the existing UI elements. A preview can be found on [youtube](https://www.youtube.com/watch?v=QXazKXy_OZo).

One of the main goals of the project is to make theming an application significantly easier. Rather than specifying raw numbers for each UI element, FlatKivy provides user-definable lookup tables for font 'style' (a mixture of actual typeface, font_size, and opacity following google's typography recommendations), colors (the entirety of the color palette in the Material Design document is built in), and a system for defining a set of arbitrary theming rules for widgets that can be applied everywhere transparently. This creates UI elements that are human readable, faster and easier to work with for programmers and designers. 

## Pros
* Modern looking
* Scalable over different resolutions
* Flexible
* Based on Google usability studies

## Cons
* Experimatal
* Undocumented
* Pioneering (few help resources available)

## Resources
* [FlatKivy](https://github.com/Kovak/FlatKivy) is freely avilable on Kovaks [github account](https://github.com/Kovak).

# Rolling Your Own
Of course, you are free to create you own widgets or override the graphical properties (both background images and drawing instructions) of the default widgets to create an entirely unique look and feel for your app. This works well for simple widgets, but can quickly become a lot of work when using more complex widgets.

If you choose this route, be sure to consider the full scope of widgets you will require before taking the plunge.