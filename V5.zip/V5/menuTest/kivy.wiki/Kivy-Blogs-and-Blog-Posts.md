# Kivy Blogs

* [Kivy Planet](http://kivy.org/planet/) - the official Kivy blog
* [/dev/blah](http://blog.tshirtman.fr/) - Gabriel Pettier's (Kivy core dev) blog
* [Dusty's Diverse Domain](http://archlinux.me/dusty/tag/kivy/) - Dusty's Kivy tutorial and blog posts
* [that doesn't make any sense](http://robertour.com/category/kivy/) - Kivy posts from Roberto Ulloa, author of ["Kivy: Interactive Applications in Python"](http://www.packtpub.com/kivy-interactive-applications-in-python/book)
* [Niko Skrypnik's Blog](http://niko.in.ua/blog/) - A lot of good Kivy posts on various topics
* [Alexander Taylor's Blog](http://inclem.net/) - Write-ups of Kivy crash course videos, probably other topics later.

# Individual Blog Posts

* 2014-05-21 :: [[Tutorial] Android development with Python and Kivy – Introduction](http://bytedebugger.wordpress.com/2014/05/21/tutorial-android-development-with-python-and-kivy-introduction/)
* 2014-05-09 :: [Theming in Kivy](http://programming.oreilly.com/2014/05/theming-in-kivy.html)
* 2014-05-01 :: [eBook Review: Creating Apps in Kivy](http://www.blog.pythonlibrary.org/2014/05/01/ebook-review-creating-apps-in-kivy/)
* 2014-03-26 :: [Kivy Interactive Sandbox Example](http://joecodeswell.wordpress.com/2014/03/25/kivy-interactive-sandbox-example/)
* 2014-02-13 :: [Configuring Kivy on PyDev](http://pydev.blogspot.com/2014/02/configuring-kivy-on-pydev.html)
* 2014-01-22 :: [Starting to Use Kivy : Developing "Letter of Heroes", An Android Alphabet Teaching Aid for Kids Part 2 of 2](http://pythonthusiast.pythonblogs.com/230_pythonthusiast/archive/1347_starting_to_use_kivy__developing_letter_of_heroes_an_android_alphabet_teaching_aid_for_kids_part_2_of_2.html)
* 2014-01-21 :: [Starting to Use Kivy : Developing "Letter of Heroes", An Android Alphabet Teaching Aid Application for Kids - Part 1 of 2](http://pythonthusiast.pythonblogs.com/230_pythonthusiast/archive/1346_starting_to_use_kivy__developing_letter_of_heroes_an_android_alphabet_teaching_aid_application_for_kids-part_1_of_2.html)
* 2013-12-17 :: [eBook Review: Kivy – Interactive Applications in Python](http://www.blog.pythonlibrary.org/2013/12/17/ebook-review-kivy-interactive-applications-python/)
* 2013-11-25 :: [Kivy 101: How to Use BoxLayouts](http://www.blog.pythonlibrary.org/2013/11/25/kivy-101-how-to-use-boxlayouts/)
* 2013-11-18 :: [How to Set up Wing IDE for Kivy on Windows](http://www.blog.pythonlibrary.org/2013/11/18/how-to-set-up-wing-ide-for-kivy-on-windows/)
* 2013-10-11 :: [How to use Python Tools for Visual Studio to develop and run Kivy Applications](http://www.ocularsoftware.com/2013/11/how-to-use-python-tools-for-visual-studio-to-develop-and-run-kivy-applications/)
* 2013-06-28 :: [Installing Kivy on a Raspberry Pi](http://wonderfulcode.tumblr.com/post/54102854344/kivy-on-raspberry-pi)
* 2012-11-23 :: [How to use PyDev to develop and run Kivy Applications (on Windows)](http://www.ocularsoftware.com/2012/11/how-to-use-pydev-to-develop-and-run-kivy-applications-on-windows/)