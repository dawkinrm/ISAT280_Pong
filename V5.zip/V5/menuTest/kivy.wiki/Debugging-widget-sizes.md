If you want to visualize the boundaries of your widgets inside a Layout, just add the following **canvas.before** with the color of your choice.

Example label 
```

Label:
    text: 'some text'
    size_hint_y: .1
    canvas.before:
        Color:
            rgba: 1., 0., 0., .3
        Rectangle:
            pos: self.pos
            size: self.size
```
