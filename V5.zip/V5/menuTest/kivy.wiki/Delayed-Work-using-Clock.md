## Summary

* *author: Mathieu Virbel*
* *kivy: >= 1.0.6*

The idea is to unroll a working loop to not block the UI. Let's imagine that you want to create thousand of images. If you are doing it in a loop, the UI will stuck until all the images are loaded and added.

You can create one image per frame for example, then the UI will be not stuck at all.

## Usage

```
#!python
from kivy.clock import Clock

def delayed_work(func, items, delay=0):
    '''Apply the func() on each item contained in items
    '''
    if not items:
        return
    def _delayed_work(*l):
        item = items.pop()
        if func(item) is False or not len(items):
            return False
        Clock.schedule_once(_delayed_work, delay)
    Clock.schedule_once(_delayed_work, delay)

#
# Usage example
#
def create_image(filename):
  image = Image(source=filename)
  my_container.add_widget(image)

items = ['img1.png', 'img2.png', 'toto.png', 'azdmlk.png']
delayed_work(create_image, items)

```


##Comments
Add your comments here...