##Summary

* *author: Thica*
* *kivy: >= 1.40*

Hello all,

I would like to share a short snippet, if you need buttons in the settings dialog to trigger further actions:

## Usage


1) We need to have a new class based on SettingItem

```
#!python

from kivy.uix.settings      import SettingItem

class SettingButtons(SettingItem):

    def __init__(self, **kwargs):
        self.register_event_type('on_release')
        super(SettingItem, self).__init__(**kwargs)
        for aButton in kwargs["buttons"]:
            oButton=Button(text=aButton['title'], font_size= '15sp')
            oButton.ID=aButton['id']
            self.add_widget(oButton)
            oButton.bind (on_release=self.On_ButtonPressed)
    def set_value(self, section, key, value):
        # set_value normally reads the configparser values and runs on an error
        # to do nothing here
        return
    def On_ButtonPressed(self,instance):
        self.panel.settings.dispatch('on_config_change',self.panel.config, self.section, self.key, instance.ID)
```


2) Register new class to settings widget

```
#!python

        Setting = Settings()
        Setting.register_type('buttons', SettingButtons)
```

3) Define Buttons in the the json string

```
#!python
{"type": "buttons","title": "$lvar(565)","desc": "$lvar(566)","section": "$var(InterfaceConfigSection)","key": "configchangebuttons","buttons":[{"title":"Add","id":"button_add"},{"title":"Del","id":"button_delete"},{"title":"Rename","id":"button_rename"}]}
```


Some explanations: You can add more than one button: Title is the caption of the button, id will identify the button in the callback function

4) Trigger your actions in On_ConfigChange(self,oSettings, oConfig, sSection, sKey, sValue), or On_ConfigChange(self, oConfig, sSection, sKey, sValue) if you use the App setting widget
sValue will hold the id

Done!

##Comments
########
Add your comments here 