# Welcome!

You have just landed at the Kivy wiki, a collection of useful information for this awesome open source cross-platform Python framework!

# Getting started

* [The Kivy Website](https://kivy.org): For the official documentation, latest downloads and user guides.
* [[Talks and Tutorials]]: Introductory videos and learning material.
* [[Setting up Kivy with various popular IDE's]]: Setting up your Kivy development environment

# Code

* [[Snippets]]: Collection of useful code snippets for common tasks. (point to what's on existing wiki home)
* [[Kivy Blogs and Blog Posts]]: Blog posts about Kivy by Kivy users from around the world
* [Profiling your Kivy application](https://github.com/chaosbuffalolabs/kivy-profilers): Learn to optimize and tweak you Kivy app
* [The Kivy Garden](https://github.com/kivy-garden/): A collection of Kivy widgets from the community

# Gaming

* [KivEnt](https://github.com/Kovak/KivEnt): an Entity Based Game Engine for Kivy by Kovak

# Mobiles

* [Plyer](https://github.com/kivy/plyer): a platform-independant api to use features commonly found on various platforms, notably mobile ones ()
* [Pyjnius](https://github.com/kivy/pyjnius): a Python module to access Java class as Python class, using JNI.
* [Pyobjus](https://github.com/kivy/pyobjus): a Python module to access Objective-C class as Python class, using Objective-C runtime reflection
* [Knappdor on github](https://github.com/knappador?tab=repositories): For Facebook/Twitter on Android, native Android dialogs and Toast, billing examples and more 

# Getting help

At Kivy, we love code and coders, so we want to help you. Feel free to ask questions, make comments or join us for a chat. All we ask is that you be nice, and follow our ["asking for help guidelines"](https://github.com/kivy/kivy/wiki/Code-of-Conduct).

* [The Kivy Users Forum](https://groups.google.com/forum/#!forum/kivy-users): Questions and answers for everyone 
* [The Kivy Developers Forum](https://groups.google.com/forum/#!forum/kivy-dev): For devs wanting to discuss the Kivy framework development 
* IRC: Join us at #Kivy on irc.freenode.net ([IRC Guidelines](http://freenode.net/channel_guidelines.shtml))

# Miscellaneous

* [[List of Kivy Projects]]: Projects that were created using Kivy
* [Kivy Artwork](https://github.com/Zen-CODE/kivybits/tree/master/Artwork) - A small collection of Kivy Logo's and wallpapers.

# Lastly

The information here is not exhaustive but provides a brief overview of the Kivy landscape. If you know of any other good resources that should be added, please let us know! Oh, and enjoy Kivy!