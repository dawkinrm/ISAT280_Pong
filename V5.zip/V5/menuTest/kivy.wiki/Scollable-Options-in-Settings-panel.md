##Summary

* *author: Thica*
* *kivy: >= 1.40*

Hello all,

I would like to share a short snippet, if you need more options than fits on the screen. The original kivy options settings will scale outside screen dimensions, if you have a larger numeber of options:

## Usage


1) We need to have a new class based on SettingOptions

```
#!python

class SettingScrollOptions(SettingOptions):

    def _create_popup(self, instance):
        
        #global oORCA
        # create the popup
       
        content         = GridLayout(cols=1, spacing='5dp')
        scrollview      = ScrollView( do_scroll_x=False)
        scrollcontent   = GridLayout(cols=1,  spacing='5dp', size_hint=(None, None))
        scrollcontent.bind(minimum_height=scrollcontent.setter('height'))
        self.popup   = popup = Popup(content=content, title=self.title, size_hint=(0.5, 0.9),  auto_dismiss=False)

        #we need to open the popup first to get the metrics 
        popup.open()
        #Add some space on top
        content.add_widget(Widget(size_hint_y=None, height=dp(2)))
        # add all the options
        uid = str(self.uid)
        for option in self.options:
            state = 'down' if option == self.value else 'normal'
            btn = ToggleButton(text=option, state=state, group=uid, size=(popup.width, dp(55)), size_hint=(None, None))
            btn.bind(on_release=self._set_option)
            scrollcontent.add_widget(btn)

        # finally, add a cancel button to return on the previous panel
        scrollview.add_widget(scrollcontent)
        content.add_widget(scrollview)
        content.add_widget(SettingSpacer())
        #btn = Button(text='Cancel', size=((oORCA.iAppWidth/2)-sp(25), dp(50)),size_hint=(None, None))
        btn = Button(text='Cancel', size=(popup.width, dp(50)),size_hint=(0.9, None))
        btn.bind(on_release=popup.dismiss)
        content.add_widget(btn)

```

2) Register new class to settings widget

```
#!python

        Setting = Settings()
        settings.register_type('scrolloptions', SettingScrollOptions)
```

3) Replace "type": "options", against "type": "scrolloptions",

Done!

##Comments
########
Add your comments here 